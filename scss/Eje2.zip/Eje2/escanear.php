<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Escanea tu identificación</title>
</head>
<body>
  <h2>Escanea tu matrícula:</h2>
  <form action="registrar.php" method="POST">
    <input type="text" name="matricula" id="matricula" autofocus>
  </form>

  <script>
    const input = document.getElementById("matricula");
    input.addEventListener("input", function () {
      if (this.value.length >= 5) { // Ajusta según la longitud de la matrícula
        this.form.submit();
      }
    });
  </script>
</body>
</html>
