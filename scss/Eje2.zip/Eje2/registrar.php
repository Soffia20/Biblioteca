<?php
session_start();
date_default_timezone_set('America/Matamoros');

require 'cone.php';

$matricula = $_POST['matricula'] ?? '';

if (!$matricula) {
    die("❌ Matrícula no proporcionada.");
}

try {
    // Verifica si existe el estudiante
    $stmt = $conn->prepare("SELECT Nombre FROM estudiantes WHERE Matricula = ?");
    $stmt->execute([$matricula]);
    $estudiante = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$estudiante) {
        die("❌ Estudiante no encontrado.");
    }

    $fecha = date('Y-m-d');

    // Verificar si ya existe una entrada sin salida para hoy
    $stmt = $conn->prepare("SELECT Id_entrada_salida FROM entrada_salida WHERE Estudiante = ? AND Fecha = ? AND Hora_salida IS NULL");
    $stmt->execute([$matricula, $fecha]);
    $registro = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($registro) {
        // Registrar hora de salida
        $hora_salida = date('H:i:s');
        $stmt = $conn->prepare("UPDATE entrada_salida SET Hora_salida = ? WHERE Id_entrada_salida = ?");
        $stmt->execute([$hora_salida, $registro['Id_entrada_salida']]);

        echo "✅ Salida registrada para <strong>{$estudiante['Nombre']}</strong> a las $hora_salida.";
    } else {
        // Guardar matrícula en sesión y redirigir a selección de servicio
        $_SESSION['matricula'] = $matricula;
        session_write_close();
        header("Location: seleccionar_servicio.php");
        exit;
    }

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
