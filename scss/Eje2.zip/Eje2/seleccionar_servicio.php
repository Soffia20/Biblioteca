<?php
session_start();
date_default_timezone_set('America/Matamoros');
require 'cone.php';

if (!isset($_SESSION['matricula'])) {
    die("❌ Matrícula no detectada.");
}

$matricula = $_SESSION['matricula'];

// Si ya se envió el servicio
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['servicio'])) {
    $servicio = $_POST['servicio'];
    $fecha = date('Y-m-d');
    $hora_entrada = date('H:i:s');

    try {
        $stmt = $conn->prepare("INSERT INTO entrada_salida (Estudiante, Servicio, Fecha, Hora_entrada) VALUES (?, ?, ?, ?)");
        $stmt->execute([$matricula, $servicio, $fecha, $hora_entrada]);

        echo "✅ Entrada registrada a las $hora_entrada.";
        unset($_SESSION['matricula']); // Limpiar la sesión
    } catch (PDOException $e) {
        echo "❌ Error al registrar entrada: " . $e->getMessage();
    }
    exit;
}

// Obtener lista de servicios
$stmt = $conn->query("SELECT Id_servicio, Nombre FROM servicios");
$servicios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Seleccionar Servicio</title>
</head>
<body>
    <h2>Selecciona el servicio</h2>
    <form method="POST">
        <select name="servicio" required>
            <option value="">-- Selecciona un servicio --</option>
            <?php foreach ($servicios as $servicio): ?>
                <option value="<?= $servicio['Id_servicio'] ?>"><?= htmlspecialchars($servicio['Nombre']) ?></option>
            <?php endforeach; ?>
        </select>
        <br><br>
        <button type="submit">Registrar entrada</button>
    </form>
</body>
</html>
